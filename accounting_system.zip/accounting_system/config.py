import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or '123456789000000000000000000000000'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///accounting.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False